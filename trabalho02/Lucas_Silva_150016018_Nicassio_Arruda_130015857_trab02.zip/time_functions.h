#ifndef TIME_FUNCTION_H
#define TIME_FUNCTION_H

  void calcute_time_elapsed(struct timeval *time_begin, struct timeval *time_end, struct timeval *result);

#endif
