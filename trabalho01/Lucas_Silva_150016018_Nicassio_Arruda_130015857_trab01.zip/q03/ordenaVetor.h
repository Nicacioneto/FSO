#ifndef ORDENA_VETOR_H
#define ORDENA_VETOR_H

  /* Função que recebe como parametro um vetor e retorna o mesmo vetor ordenado
      em ordem crescente*/
  Vetor ordenaVetor(Vetor vetor);

#endif
