#ifndef ENTRADA_H_INCLUDED
#define ENTRADA_H_INCLUDED

void entrada();
void saida();

#endif
