#ifndef PONTO_H
#define PONTO_H

typedef struct
{
  double x;
  double y;

}Vertice;

typedef struct
{
  Vertice vertices[4];

}Quadrilatero;

#endif
