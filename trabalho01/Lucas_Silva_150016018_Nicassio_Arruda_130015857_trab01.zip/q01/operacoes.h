#ifndef OPERACOES_H_INCLUDED
#define OPERACOES_H_INCLUDED

double calculaComprimento(Quadrilatero *quadrilatero);
int convexo(Quadrilatero *quadrilatero);
double calculaArea(Quadrilatero *quadrilatero);

#endif
